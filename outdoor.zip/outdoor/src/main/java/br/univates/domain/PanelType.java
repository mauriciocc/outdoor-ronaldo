package br.univates.domain;

public enum PanelType {
    Regular,
    Image,
    Weather
}