package br.univates.domain;

public enum MessageType {
    Animated,
    Static,
    System
}
